import sqlite3
import os

# Garante que a pasta instance existe
if not os.path.exists('instance'):
    os.makedirs('instance')

def get_db_connection(db_name):
    # Conecta no banco especifico (ex: instance/carabeli.db ou instance/users.db)
    conn = sqlite3.connect(f'instance/{db_name}.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_dbs():
    # 1. Banco da Clínica Carabelli
    conn = get_db_connection('carabeli')
    conn.execute('''CREATE TABLE IF NOT EXISTS pacientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        cpf TEXT,
        telefone TEXT,
        nascimento TEXT,
        plano TEXT,
        cep TEXT,
        endereco TEXT,
        anamnese TEXT
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS agenda (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paciente_id INTEGER,
        paciente_nome TEXT,
        start_time TEXT,
        status TEXT, -- Agendado, Confirmado, Concluido, Cancelado
        obs TEXT
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS financeiro (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paciente_id INTEGER,
        data TEXT,
        servico TEXT,
        valor REAL,
        obs TEXT
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS estoque (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item TEXT,
        qtd INTEGER,
        unidade TEXT,
        validade TEXT
    )''')
    # 2. Banco GLOBAL de Usuários (Login)
    conn_users = get_db_connection('users')
    # Adicionei 'cargo' e defini padrão empresa como 'Pendente'
    conn_users.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        empresa TEXT DEFAULT 'Pendente',
        cargo TEXT DEFAULT 'Visitante'
    )''')
    
    # Tenta adicionar a coluna cargo se ela nao existir (migração gambiarra para não perder dados)
    try:
        conn_users.execute("ALTER TABLE users ADD COLUMN cargo TEXT DEFAULT 'Visitante'")
    except:
        pass # Se der erro é porque já existe, ignora
        
    conn_users.commit()
    conn_users.close()
    # Tabela para mensagens do WhatsApp
    conn.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        remote_jid TEXT,
        paciente_nome TEXT,
        direction TEXT, -- 'in' (recebida) ou 'out' (enviada)
        message TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        read INTEGER DEFAULT 0
    )''')
    # Contexto do Robô
    conn.execute('''CREATE TABLE IF NOT EXISTS chat_contexts (
        remote_jid TEXT PRIMARY KEY,
        stage TEXT,
        temp_data TEXT
    )''')
    # Configuração do WhatsApp
    conn.execute('''CREATE TABLE IF NOT EXISTS whatsapp_config (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        hora_envio TEXT DEFAULT '09:00',
        status TEXT DEFAULT 'ativo'
    )''')
    # Inicializa config se não existir
    conn.execute("INSERT OR IGNORE INTO whatsapp_config (id, hora_envio, status) VALUES (1, '09:00', 'ativo')")
    
    # Tabela de Correção de IDs (Nova)
    conn.execute('''CREATE TABLE IF NOT EXISTS id_corrections (
        wrong_id TEXT PRIMARY KEY, 
        real_id TEXT
    )''')
    conn.commit()
    conn.close()

    # 2. Banco GLOBAL de Usuários (Login)
    conn_users = get_db_connection('users')
    conn_users.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        empresa TEXT DEFAULT 'carabeli'
    )''')
    conn_users.commit()
    conn_users.close()

    print("✅ Bancos de dados inicializados com sucesso!")