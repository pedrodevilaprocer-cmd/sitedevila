import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'segredo_devila_tech_fixo_2025')
    UPLOAD_BASE_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads', 'producao')
    SAFE_UPLOADS_FOLDER = os.path.join(BASE_DIR, 'safe_uploads')
    
    # Tokens e APIs
    PROCER_TOKEN = os.getenv('PROCER_TOKEN', "eyJhbGciOiJSUzI1NiIsImFscGhhIjo5NjUwMH0...") # Seu token longo aqui se não estiver no .env
    PROCER_API_BUSCA = "https://n8n.procer.com.br/webhook/item-m2"
    PROCER_API_DOO = "https://n8n.procer.com.br/webhook/pasta-doo"
    
    # Caminhos de Banco
    DB_MAIN = os.path.join(BASE_DIR, 'instance', 'database.db')
    DB_CARABELI = os.path.join(BASE_DIR, 'instance', 'carabeli.db')

    # Garante pastas
    for path in [UPLOAD_BASE_FOLDER, SAFE_UPLOADS_FOLDER, os.path.join(BASE_DIR, 'instance')]:
        if not os.path.exists(path):
            os.makedirs(path)