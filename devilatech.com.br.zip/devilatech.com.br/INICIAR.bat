@echo off
setlocal
title SISTEMA DEVILA TECH - AUTO START
color 0B
cd /d "%~dp0"

cls
echo ========================================================
echo.
echo      [ DEVILA TECH ] - SISTEMA DE GESTAO INTEGRADO
echo      Evolution API v2 + Python Flask + AI
echo.
echo ========================================================
echo.

:: ============================================================
:: 2. CONFIGURAÇÃO DE REDE E FIREWALL (CRÍTICO)
:: ============================================================
echo [1/6] Configurando Firewall do Windows (Porta 8000)...
powershell -Command "New-NetFirewallRule -DisplayName 'Liberar Python Flask 8000' -Direction Inbound -LocalPort 8000 -Protocol TCP -Action Allow -ErrorAction SilentlyContinue" >nul 2>&1
echo      Status: Porta 8000 liberada para o Webhook.
echo.

:: ============================================================
:: 4. GESTÃO DO DOCKER (EVOLUTION API)
:: ============================================================
echo [3/6] Verificando Docker...
docker info >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo [ERRO CRITICO] O Docker Desktop nao esta rodando!
    echo Por favor, abra o Docker Desktop e tente novamente.
    echo.
    pause
    exit
)


:: Inicia o Python
python run.py

pause