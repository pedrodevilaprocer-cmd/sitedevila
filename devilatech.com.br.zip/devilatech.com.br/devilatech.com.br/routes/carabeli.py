import os
import time
import requests
import re
import json
import sqlite3
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, render_template, session, redirect, send_from_directory
from werkzeug.utils import secure_filename
from config import Config
from database import get_db_connection
from utils import padronizar_telefone, get_target_folder

carabeli_bp = Blueprint('carabeli', __name__)

WA_API_URL = "http://127.0.0.1:8081"
WA_API_KEY = "123456"
WA_INSTANCE_NAME = "clinica_carabelli"
WA_WEBHOOK_URL = "http://host.docker.internal:8000/api/webhook/whatsapp"

# ==============================================================================
# TABELA DE CORREÇÃO DE IDs (MANTER ISSO)
# ==============================================================================
def init_correction_table():
    conn = get_db_connection('carabeli')
    conn.execute('''CREATE TABLE IF NOT EXISTS id_corrections (wrong_id TEXT PRIMARY KEY, real_id TEXT)''')
    conn.commit(); conn.close()
try: init_correction_table()
except: pass

@carabeli_bp.route('/api/clinica/fix_id', methods=['GET', 'POST', 'DELETE'])
def api_fix_id():
    conn = get_db_connection('carabeli')
    if request.method == 'POST':
        wrong = re.sub(r'\D', '', request.json['wrong_id'])
        real = re.sub(r'\D', '', request.json['real_id'])
        conn.execute("INSERT OR REPLACE INTO id_corrections (wrong_id, real_id) VALUES (?, ?)", (wrong, real))
        conn.execute("UPDATE messages SET remote_jid = ? WHERE remote_jid LIKE ?", (real, f'%{wrong}%'))
        conn.execute("UPDATE chat_contexts SET remote_jid = ? WHERE remote_jid LIKE ?", (real, f'%{wrong}%'))
        conn.commit(); conn.close()
        return jsonify({'success': True})
    if request.method == 'GET':
        rows = conn.execute("SELECT * FROM id_corrections").fetchall(); conn.close()
        return jsonify([dict(x) for x in rows])
    if request.method == 'DELETE':
        conn.execute("DELETE FROM id_corrections WHERE wrong_id = ?", (request.args.get('wrong_id'),)); conn.commit(); conn.close()
        return jsonify({'success': True})

@carabeli_bp.route('/fix_webhook')
def fix_webhook():
    headers = {"apikey": WA_API_KEY}
    payload = {"enabled": True, "url": WA_WEBHOOK_URL, "webhookByEvents": False, "events": ["MESSAGES_UPSERT"]}
    try:
        r = requests.post(f"{WA_API_URL}/webhook/set/{WA_INSTANCE_NAME}", json=payload, headers=headers, timeout=5)
        if r.status_code == 404: r = requests.post(f"{WA_API_URL}/instance/set-webhook/{WA_INSTANCE_NAME}", json=payload, headers=headers, timeout=5)
        return jsonify({"status": "Webhook reconfigurado", "code": r.status_code})
    except Exception as e: return jsonify({"erro": str(e)})

@carabeli_bp.route('/cliente/carabeli')
def rota_carabeli(): 
    return render_template('clientes/carabeli_dashboard.html', user_name=session.get('nome','Doutora')) if session.get('empresa')=='carabeli' else redirect('/login')

# ==============================================================================
# 🤖 WEBHOOK - LÓGICA DO ROBÔ (CORRIGIDA)
# ==============================================================================
@carabeli_bp.route('/api/webhook/whatsapp', methods=['POST'])
def whatsapp_webhook():
    try: raw_body = request.json
    except: return jsonify({'status': 'invalid_json'}), 400

    try:
        data = raw_body.get('data', raw_body)
        if isinstance(data, list): data = data[0] if len(data) > 0 else {}
        key = data.get('key', {})
        raw_jid = key.get('remoteJid') or key.get('participant') or data.get('from', '')
        
        if not raw_jid or 'status@broadcast' in raw_jid or key.get('fromMe') is True: 
            return jsonify({'status': 'ignored'}), 200

        msg_obj = data.get('message', {})
        texto = (msg_obj.get('conversation') or msg_obj.get('extendedTextMessage', {}).get('text') or msg_obj.get('imageMessage', {}).get('caption') or "")
        
        if not texto: return jsonify({'status': 'ignored_no_text'}), 200

        # CORREÇÃO DE ID
        jid_numerico = re.sub(r'\D', '', raw_jid)
        conn = get_db_connection('carabeli')
        correction = conn.execute("SELECT real_id FROM id_corrections WHERE wrong_id = ?", (jid_numerico,)).fetchone()
        remote_jid = correction['real_id'] if correction else padronizar_telefone(raw_jid)
        push_name = data.get('pushName') or "Paciente"
        
        print(f"📩 MENSAGEM: {push_name} | {remote_jid} | {texto}", flush=True)
        
        conn.execute("INSERT INTO messages (remote_jid, paciente_nome, direction, message, read) VALUES (?, ?, ?, ?, ?)", (remote_jid, push_name, 'in', texto, 0))
        conn.commit(); conn.close()

        from services.whatsapp_bot import enviar_whatsapp_api 
        # Limpeza básica do texto
        msg_clean = texto.lower().strip().replace('.', '').replace(',', '')
        
        ctx = get_context(remote_jid)
        
        # ---------------------------------------------------------
        # FLUXO 1: REMARCAÇÃO (ESPERANDO NOVA DATA)
        # ---------------------------------------------------------
        if ctx and ctx['stage'] == 'esperando_data':
            try:
                agora = datetime.now(); dia, mes, ano = 0, 0, agora.year
                match = re.search(r'(\d{1,2})[\/.-](\d{1,2})', msg_clean)
                if match:
                    dia, mes = int(match.group(1)), int(match.group(2))
                    if mes < agora.month or (mes == agora.month and dia < agora.day): ano += 1
                else: enviar_whatsapp_api(remote_jid, "Não entendi a data. Digite assim: 25/12"); return jsonify({'status':'processed'}), 200
                
                data_iso = datetime(ano, mes, dia).strftime('%Y-%m-%d'); livres = get_horarios_livres(data_iso)
                if not livres: enviar_whatsapp_api(remote_jid, f"Poxa, esse dia está lotado! 😕 Teria outra data de preferência?")
                else: msg = "\n".join([f"🔹 {h}" for h in livres]); enviar_whatsapp_api(remote_jid, f"Tenho estes horários livres para o dia {dia}/{mes}:\n\n{msg}\n\nQual fica melhor para você? (Digite o horário)"); set_context(remote_jid, 'esperando_hora', data_iso) 
            except: enviar_whatsapp_api(remote_jid, "Data inválida. Tente novamente (Dia/Mês).")
            return jsonify({'status':'processed'}), 200

        if ctx and ctx['stage'] == 'esperando_hora':
            match = re.search(r'(\d{1,2})[:hH]?(\d{2})?', msg_clean)
            if match:
                h, m = match.group(1).zfill(2), match.group(2) if match.group(2) else "00"; hora = f"{h}:{m}"; livres = get_horarios_livres(ctx['temp_data'])
                if hora not in livres: enviar_whatsapp_api(remote_jid, "Esse horário acabou de ser ocupado ou não existe. Escolha outro da lista acima."); return jsonify({'status':'processed'}), 200
                
                conn = get_db_connection('carabeli')
                paciente = conn.execute("SELECT id, nome FROM pacientes WHERE telefone LIKE ?", (f'%{remote_jid[-8:]}%',)).fetchone()
                if paciente:
                    conn.execute("INSERT INTO agenda (paciente_id, paciente_nome, start_time, status) VALUES (?,?,?,?)", (paciente['id'], paciente['nome'], f"{ctx['temp_data']}T{hora}", 'Confirmado')); conn.commit()
                    enviar_whatsapp_api(remote_jid, f"Tudo certo! 😍\n\nSeu horário está confirmado para dia {datetime.strptime(ctx['temp_data'], '%Y-%m-%d').strftime('%d/%m')} às {hora}.\n\nTe esperamos aqui na clínica! 🦷✨"); clear_context(remote_jid) 
                else: enviar_whatsapp_api(remote_jid, "Não encontrei seu cadastro. Entre em contato com a secretária.")
            return jsonify({'status':'processed'}), 200

        # ---------------------------------------------------------
        # FLUXO 2: DETECÇÃO DE RESPOSTAS (SIM / NÃO)
        # ---------------------------------------------------------
        
        # Lista de palavras que indicam "SIM"
        palavras_sim = ['sim', '1', 'ok', 'confirmado', 'confirmo', 'pode', 'claro', 'beleza', 'tá bom']
        
        # Lista de palavras que indicam "NÃO"
        palavras_nao = ['não', 'nao', '2', 'cancelar', 'desmarcar', 'remarcar', 'não posso', 'nao posso', 'não vou', 'imprevisto']

        # Verifica se alguma palavra "SIM" está na mensagem
        if any(w in msg_clean for w in palavras_sim):
            conn = get_db_connection('carabeli')
            # Busca agendamento futuro (Agendado OU Confirmado, para evitar erro se já confirmou)
            agd = conn.execute("SELECT id FROM agenda WHERE paciente_id IN (SELECT id FROM pacientes WHERE telefone LIKE ?) AND start_time > datetime('now') AND status IN ('Agendado', 'Confirmado') LIMIT 1", (f'%{remote_jid[-8:]}%',)).fetchone()
            
            if agd: 
                conn.execute("UPDATE agenda SET status='Confirmado' WHERE id=?", (agd['id'],)); conn.commit()
                enviar_whatsapp_api(remote_jid, "Maravilha! Seu horário está confirmadíssimo. Até lá! 🥰")
            else: 
                # Se não tem agendamento, responde genérico
                enviar_whatsapp_api(remote_jid, "Obrigada pelo retorno! 😉")
            conn.close()

        # Verifica se alguma palavra "NÃO" está na mensagem
        elif any(w in msg_clean for w in palavras_nao):
            conn = get_db_connection('carabeli')
            # Busca agendamento futuro para cancelar (Aceita cancelar mesmo se já estava Confirmado)
            agd = conn.execute("SELECT id FROM agenda WHERE paciente_id IN (SELECT id FROM pacientes WHERE telefone LIKE ?) AND start_time > datetime('now') AND status IN ('Agendado', 'Confirmado') LIMIT 1", (f'%{remote_jid[-8:]}%',)).fetchone()
            
            if agd:
                # 1. Cancela o horário antigo
                conn.execute("UPDATE agenda SET status='Cancelado' WHERE id=?", (agd['id'],)); conn.commit()
                
                # 2. Mensagem educada sugerindo nova data
                msg_educada = (
                    "Poxa, que pena que não poderá vir. 😔 Mas não tem problema, imprevistos acontecem!\n\n"
                    "Vamos aproveitar para já deixar remarcado e garantir seu cuidado? 🦷✨\n\n"
                    "📅 Qual data fica melhor para você? (Digite o Dia/Mês. Ex: 20/12)"
                )
                enviar_whatsapp_api(remote_jid, msg_educada)
                
                # 3. Ativa modo de espera pela data
                set_context(remote_jid, 'esperando_data')
            else:
                # Se disse não, mas não tinha agendamento
                enviar_whatsapp_api(remote_jid, "Entendi. Se precisar de algo, é só chamar! 😊")
            
            conn.close()

        return jsonify({'status':'processed'}), 200
    except Exception as e: print(f"❌ ERRO: {e}"); return jsonify({'error':str(e), 'status': 'error_handled'}), 200

# --- DEMAIS ROTAS (MANTIDAS) ---
@carabeli_bp.route('/api/clinica/agenda', methods=['GET','POST','DELETE','PUT'])
def api_agenda_clinica():
    conn = get_db_connection('carabeli')
    if request.method=='GET': r=conn.execute("SELECT * FROM agenda WHERE status != 'Cancelado'").fetchall(); conn.close(); return jsonify([{'id':x['id'],'title':x['paciente_nome'],'start':x['start_time'],'status':x['status'],'paciente_id':x['paciente_id']} for x in r])
    if request.method=='POST': conn.execute("INSERT INTO agenda (paciente_id, paciente_nome, start_time, status) VALUES (?,?,?,?)",(request.json['paciente_id'],request.json['paciente_nome'],request.json['start'], 'Agendado')); conn.commit()
    if request.method=='DELETE': conn.execute("DELETE FROM agenda WHERE id=?",(request.args.get('id'),)); conn.commit()
    if request.method=='PUT': conn.execute("UPDATE agenda SET status=? WHERE id=?", (request.json['status'], request.json['id'])); conn.commit()
    conn.close(); return jsonify({'success':True})

def set_context(jid, stage, data=""): conn=get_db_connection('carabeli'); conn.execute("INSERT OR REPLACE INTO chat_contexts (remote_jid, stage, temp_data) VALUES (?, ?, ?)", (jid, stage, data)); conn.commit(); conn.close()
def get_context(jid): conn=get_db_connection('carabeli'); ctx=conn.execute("SELECT * FROM chat_contexts WHERE remote_jid=?", (jid,)).fetchone(); conn.close(); return ctx
def clear_context(jid): conn=get_db_connection('carabeli'); conn.execute("DELETE FROM chat_contexts WHERE remote_jid=?", (jid,)); conn.commit(); conn.close()
def get_horarios_livres(data_iso): conn=get_db_connection('carabeli'); ocupados=conn.execute("SELECT start_time FROM agenda WHERE start_time LIKE ? AND status != 'Cancelado'", (f"{data_iso}%",)).fetchall(); conn.close(); h_ocup=[o['start_time'].split('T')[1][:5] for o in ocupados]; return [s for s in ["08:00","09:00","10:00","11:00","13:00","14:00","15:00","16:00","17:00"] if s not in h_ocup]

@carabeli_bp.route('/api/clinica/whatsapp/connect')
def api_wa_conn():
    headers = {"apikey": WA_API_KEY}
    try:
        r = requests.get(f"{WA_API_URL}/instance/connect/{WA_INSTANCE_NAME}", headers=headers, timeout=5)
        if r.status_code == 404: requests.post(f"{WA_API_URL}/instance/create", json={"instanceName": WA_INSTANCE_NAME}, headers=headers); time.sleep(3)
        try: requests.post(f"{WA_API_URL}/webhook/set/{WA_INSTANCE_NAME}", json={"webhookUrl": WA_WEBHOOK_URL,"webhookByEvents": False,"events": ["MESSAGES_UPSERT"]}, headers=headers, timeout=2)
        except: pass
        for i in range(10): 
            try:
                r = requests.get(f"{WA_API_URL}/instance/connect/{WA_INSTANCE_NAME}", headers=headers, timeout=5)
                if r.status_code == 200:
                    data = r.json()
                    if 'base64' in data: return jsonify({'status': 'qrcode', 'base64': data['base64']})
                    if 'instance' in data and data['instance'].get('state') == 'open': return jsonify({'status': 'connected'})
            except: pass
            time.sleep(1.5)
        return jsonify({'status': 'error', 'message': 'Iniciando...'})
    except Exception as e: return jsonify({'status': 'error', 'message': 'API Offline'})

@carabeli_bp.route('/api/clinica/whatsapp/logout', methods=['DELETE'])
def api_wa_logout():
    try: requests.delete(f"{WA_API_URL}/instance/logout/{WA_INSTANCE_NAME}", headers={"apikey": WA_API_KEY}, timeout=5); return jsonify({'success':True})
    except: return jsonify({'success':False})

@carabeli_bp.route('/api/clinica/whatsapp/config', methods=['GET','POST'])
def api_wa_cfg(): 
    conn=get_db_connection('carabeli')
    if request.method=='GET': r=conn.execute("SELECT * FROM whatsapp_config").fetchone(); conn.close(); return jsonify(dict(r))
    conn.execute("UPDATE whatsapp_config SET hora_envio=?, status=?",(request.json['hora_envio'],request.json['status'])); conn.commit(); conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/preencher_ficha/<int:id>', methods=['GET', 'POST'])
def preencher_ficha(id):
    conn = get_db_connection('carabeli')
    if request.method == 'POST': conn.execute('UPDATE pacientes SET anamnese = ? WHERE id = ?', (request.form.get('anamnese_completa'), id)); conn.commit(); conn.close(); return render_template('anamnese_paciente.html', sucesso=True)
    p = conn.execute("SELECT * FROM pacientes WHERE id=?", (id,)).fetchone(); conn.close()
    return render_template('anamnese_paciente.html', nome_paciente=p['nome'], sucesso=False) if p else "Paciente não encontrado."

@carabeli_bp.route('/api/clinica/pacientes')
def api_pacientes():
    q = request.args.get('q', '').strip(); conn = get_db_connection('carabeli')
    p = conn.execute("SELECT * FROM pacientes WHERE nome LIKE ? LIMIT 50", (f"%{q}%",)).fetchall() if q else conn.execute("SELECT * FROM pacientes LIMIT 50").fetchall()
    conn.close(); return jsonify([dict(x) for x in p])

@carabeli_bp.route('/api/clinica/paciente/novo', methods=['POST'])
def api_pac_novo():
    d=request.json; conn=get_db_connection('carabeli')
    conn.execute("INSERT INTO pacientes (nome, cpf, telefone) VALUES (?,?,?)", (d['nome'],d.get('cpf'),d.get('telefone'))); conn.commit(); conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/clinica/paciente/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def api_pac_single(id):
    conn = get_db_connection('carabeli')
    if request.method=='GET': p=conn.execute("SELECT * FROM pacientes WHERE id=?",(id,)).fetchone(); conn.close(); return jsonify(dict(p)) if p else jsonify({})
    if request.method=='DELETE': conn.execute("DELETE FROM pacientes WHERE id=?",(id,)); conn.commit(); conn.close(); return jsonify({'success':True})
    d=request.json; conn.execute("UPDATE pacientes SET nome=?, cpf=?, telefone=? WHERE id=?", (d['nome'],d.get('cpf'),d.get('telefone'), id)); conn.commit(); conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/clinica/financeiro/<pid>', methods=['GET','POST'])
def api_fin(pid):
    conn=get_db_connection('carabeli')
    if request.method=='POST': d=request.json; conn.execute("INSERT INTO financeiro (paciente_id, data, servico, valor) VALUES (?,?,?,?)",(pid,d['data'],d['servico'],d['valor'])); conn.commit()
    h=conn.execute("SELECT * FROM financeiro WHERE paciente_id=?",(pid,)).fetchall(); p=conn.execute("SELECT nome FROM pacientes WHERE id=?", (pid,)).fetchone(); conn.close(); return jsonify({'historico':[dict(x) for x in h], 'paciente': dict(p) if p else {'nome': 'Desconhecido'}})

@carabeli_bp.route('/api/clinica/estoque', methods=['GET','POST','DELETE'])
def api_est():
    conn=get_db_connection('carabeli')
    if request.method=='GET': r=conn.execute("SELECT * FROM estoque").fetchall(); conn.close(); return jsonify([dict(x) for x in r])
    if request.method=='POST': d=request.json; conn.execute("INSERT INTO estoque (item, qtd, unidade, validade) VALUES (?,?,?,?)",(d['item'],d['qtd'],d['unidade'],d['validade'])); conn.commit()
    if request.method=='DELETE': conn.execute("DELETE FROM estoque WHERE id=?",(request.args.get('id'),)); conn.commit()
    conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/chat/contacts')
def api_chat_contacts(): 
    conn=get_db_connection('carabeli')
    c=conn.execute("SELECT remote_jid, paciente_nome, message, timestamp, (SELECT COUNT(*) FROM messages m2 WHERE m2.remote_jid = m1.remote_jid AND m2.read = 0) as unread FROM messages m1 GROUP BY remote_jid ORDER BY timestamp DESC").fetchall()
    conn.close()
    return jsonify([dict(x) for x in c])

@carabeli_bp.route('/api/chat/history/<jid>')
def api_chat_history(jid): 
    conn=get_db_connection('carabeli')
    # Use o numero corrigido se ja existir no banco
    m=conn.execute("SELECT * FROM messages WHERE remote_jid=? ORDER BY timestamp ASC", (jid,)).fetchall()
    conn.execute("UPDATE messages SET read=1 WHERE remote_jid=?",(jid,))
    conn.commit()
    conn.close()
    return jsonify([dict(x) for x in m])

@carabeli_bp.route('/api/chat/profile_pic/<jid>')
def api_chat_pfp(jid):
    headers = {"apikey": WA_API_KEY}
    try:
        r = requests.get(f"{WA_API_URL}/chat/fetchProfilePictureUrl/{WA_INSTANCE_NAME}", params={"number": jid}, headers=headers, timeout=3)
        if r.status_code == 200:
            data = r.json()
            url = data.get('profilePictureUrl') or data.get('url')
            if url: return jsonify({'url': url})
    except: pass
    return jsonify({'url': None})

@carabeli_bp.route('/api/chat/send', methods=['POST'])
def api_chat_send():
    from services.whatsapp_bot import enviar_whatsapp_api; d=request.json; jid=padronizar_telefone(d['jid'])
    if enviar_whatsapp_api(jid, d['message']):
        conn=get_db_connection('carabeli'); conn.execute("INSERT INTO messages (remote_jid, paciente_nome, direction, message, read) VALUES (?, ?, 'out', ?, 1)", (jid, d.get('name', jid), d['message'])); conn.commit(); conn.close(); return jsonify({'success':True})
    return jsonify({'success':False}), 500

@carabeli_bp.route('/api/clinica/faturamento_hoje')
def api_fat_hoje(): conn = get_db_connection('carabeli'); hoje = datetime.now().strftime('%Y-%m-%d'); res = conn.execute("SELECT SUM(valor) as total FROM financeiro WHERE data = ?", (hoje,)).fetchone(); conn.close(); return jsonify({'total': res['total'] if res and res['total'] else 0.0})

@carabeli_bp.route('/api/clinica/relatorios')
def api_relatorios(): conn = get_db_connection('carabeli'); fin = conn.execute("SELECT f.*, p.nome as paciente_nome FROM financeiro f LEFT JOIN pacientes p ON f.paciente_id = p.id ORDER BY f.data DESC").fetchall(); conn.close(); return jsonify({'financeiro': [dict(x) for x in fin]})

@carabeli_bp.route('/api/anexos/<target_id>', methods=['GET','POST','DELETE'])
def api_anexos(target_id):
    emp=session.get('empresa','carabeli'); full_path,_=get_target_folder(emp, target_id)
    if request.method=='POST': f=request.files['file']; f.save(os.path.join(full_path, secure_filename(f.filename))); return jsonify({'success':True})
    if request.method=='DELETE': 
        try: os.remove(os.path.join(full_path, request.json['filename']))
        except: pass
        return jsonify({'success':True})
    try: files = [{'name':f,'url':f"/arquivo_seguro/{emp}/{os.path.basename(full_path)}/{f}", 'is_dir':False, 'can_delete':True} for f in os.listdir(full_path)]
    except: files = []
    return jsonify({'items': files})

@carabeli_bp.route('/arquivo_seguro/<company>/<folder>/<filename>')
def serve_file(company, folder, filename): return send_from_directory(os.path.join(Config.SAFE_UPLOADS_FOLDER, company, folder), filename)