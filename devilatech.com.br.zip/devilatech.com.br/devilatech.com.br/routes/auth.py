from flask import Blueprint, render_template, request, redirect, session, url_for, flash
from werkzeug.security import check_password_hash, generate_password_hash
from database import get_db_connection

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/')
def index():
    # Pega a identidade do navegador e converte para minúsculas
    user_agent = request.headers.get('User-Agent', '').lower()
    
    # Palavras-chave comuns em celulares
    if 'mobile' in user_agent or 'android' in user_agent or 'iphone' in user_agent:
        return render_template('index_mobile.html')
    else:
        return render_template('index_pc.html')

# --- LOGIN ---
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('password')
        
        if not email or not senha:
            flash('Preencha todos os campos.', 'warning')
            return render_template('login.html')

        # 1. LÓGICA DO MESTRE (VOCÊ)
        if email == 'contato@devilatech.com.br':
            conn = get_db_connection('users')
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            conn.close()
            
            if user and check_password_hash(user['password'], senha):
                session.clear()
                session['user_id'] = user['id']
                session['email'] = user['email']
                session['nome'] = "Mestre"
                session['is_admin'] = True 
                return redirect('/super_admin')
            else:
                flash('Credenciais inválidas.', 'danger')

        # 2. LÓGICA DE CLIENTES
        else:
            conn = get_db_connection('users')
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            conn.close()

            if user and check_password_hash(user['password'], senha):
                session.clear()
                # --- CORREÇÃO CRÍTICA AQUI ---
                # Convertemos a linha do banco para Dicionário para usar o .get()
                user_dict = dict(user) 
                
                session['user_id'] = user_dict['id']
                session['email'] = user_dict['email']
                session['nome'] = user_dict['nome']
                
                # Agora o .get funciona porque transformamos em dict
                empresa_user = user_dict.get('empresa', 'Pendente')
                session['empresa'] = empresa_user
                
                if empresa_user == 'Pendente':
                    flash('Cadastro em análise pelo administrador.', 'warning')
                    session.clear()
                    return redirect('/login')
                
                return redirect(f'/cliente/{empresa_user}')
            else:
                flash('Email ou senha incorretos.', 'danger')

    return render_template('login.html')

# --- CADASTRO ---
@auth_bp.route('/cadastro', methods=['GET', 'POST'])
@auth_bp.route('/register', methods=['GET', 'POST'])
@auth_bp.route('/registrar', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('password')
        empresa = 'Pendente' 
        
        if not nome or not email or not senha:
            flash('Preencha tudo.', 'warning')
            return render_template('register.html')

        conn = get_db_connection('users')
        try:
            if conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone():
                flash('Email já existe.', 'warning')
            else:
                hashed = generate_password_hash(senha, method='pbkdf2:sha256')
                conn.execute("INSERT INTO users (nome, email, password, empresa, cargo) VALUES (?, ?, ?, ?, ?)", 
                             (nome, email, hashed, empresa, 'Visitante'))
                conn.commit()
                flash('Criado com sucesso! Aguarde aprovação.', 'success')
                return redirect('/login')
        except Exception as e:
            flash(f'Erro: {str(e)}', 'danger')
        finally:
            conn.close()

    return render_template('register.html')

# --- ROTAS ADMIN ---
@auth_bp.route('/super_admin')
def super_admin_selection():
    if not session.get('is_admin'): return redirect('/login')
    conn = get_db_connection('users')
    users = conn.execute("SELECT * FROM users ORDER BY id DESC").fetchall()
    conn.close()
    return render_template('super_admin.html', users=users)

@auth_bp.route('/admin/access/<company>')
def admin_access_company(company):
    if not session.get('is_admin'): return redirect('/login')
    session['empresa'] = company
    return redirect(f'/cliente/{company}')

# Ações de Admin (Update/Delete)
@auth_bp.route('/admin/update_user', methods=['POST'])
def admin_update_user():
    if not session.get('is_admin'): return redirect('/login')
    conn = get_db_connection('users')
    conn.execute("UPDATE users SET empresa = ?, cargo = ? WHERE id = ?", 
                 (request.form.get('nova_empresa'), request.form.get('novo_cargo'), request.form.get('user_id')))
    conn.commit()
    conn.close()
    return redirect('/super_admin')

@auth_bp.route('/admin/delete_user', methods=['POST'])
def admin_delete_user():
    if not session.get('is_admin'): return redirect('/login')
    conn = get_db_connection('users')
    conn.execute("DELETE FROM users WHERE id = ?", (request.form.get('user_id'),))
    conn.commit()
    conn.close()
    return redirect('/super_admin')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect('/')