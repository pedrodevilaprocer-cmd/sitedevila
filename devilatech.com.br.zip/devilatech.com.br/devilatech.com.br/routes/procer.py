import os
import requests
from io import BytesIO
import openpyxl
from flask import Blueprint, request, jsonify, render_template, session, redirect, send_file
from werkzeug.utils import secure_filename
from config import Config
from services.procer_logic import processar_logica_engenharia, processar_chicote_excel

procer_bp = Blueprint('procer', __name__)

@procer_bp.route('/cliente/procer')
def rota_procer(): return render_template('clientes/procer_dashboard.html', user_name=session.get('nome', 'Usuário')) if session.get('empresa')=='procer' else redirect('/login')

@procer_bp.route('/cliente/procer/testes/lista')
def procer_testes_lista(): 
    # Exemplo de dados mockados para testes
    ops = [
        {'numero': '105802', 'cliente': 'Cliente A', 'item_desc': 'Painel QGBT', 'operacao': 'Montagem', 'saldo': 5, 'previsao': '20/12', 'item_id': 'PNL-01'},
        {'numero': '105803', 'cliente': 'Cliente B', 'item_desc': 'Painel CCM', 'operacao': 'Teste', 'saldo': 2, 'previsao': '22/12', 'item_id': 'PNL-02'}
    ]
    return render_template('clientes/procer_testes.html', ops=ops) if session.get('empresa')=='procer' else redirect('/login')

@procer_bp.route('/cliente/procer/projetos')
def rota_procer_projetos(): return render_template('clientes/procer_projetos.html') if session.get('empresa')=='procer' else redirect('/login')

@procer_bp.route('/api/procer/processar_arquivo', methods=['POST'])
def api_procer_processar():
    if 'file' not in request.files: return jsonify({'error': 'Arquivo não enviado'}), 400
    f = request.files['file']; filename = secure_filename(f.filename); mode = request.form.get('mode', 'pcp'); quadro_name = request.form.get('quadro_name', '')
    temp = os.path.join(Config.SAFE_UPLOADS_FOLDER, f"temp_{filename}"); f.save(temp)
    try:
        if mode == 'chicote':
            dados, alerts = processar_chicote_excel(temp, quadro_name)
        else:
            dados, alerts = processar_logica_engenharia(temp, quadro_name, mode)
        os.remove(temp); return jsonify({'success': True, 'data': dados, 'alerts': alerts})
    except Exception as e:
        if os.path.exists(temp): os.remove(temp)
        return jsonify({'error': str(e)}), 500

@procer_bp.route('/api/procer/upload_doo', methods=['POST'])
def api_procer_upload_doo():
    if 'file' not in request.files: return jsonify({'error': 'Arquivo não enviado'}), 400
    f = request.files['file']; kw = request.form.get('kw', '')
    filename = secure_filename(f.filename)
    temp_path = os.path.join(Config.SAFE_UPLOADS_FOLDER, f"doo_{filename}")
    f.save(temp_path)
    try:
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Info"
        ws.append(["KW", "Nome_Arquivo_Original"]); ws.append([kw, filename])
        xlsx_io = BytesIO(); wb.save(xlsx_io); xlsx_io.seek(0)
        
        headers = {"authorization": Config.PROCER_TOKEN}
        with open(temp_path, 'rb') as pdf_file:
            files_payload = [('arquivo', (filename, pdf_file, 'application/pdf')), ('arquivo_dados', (f'{kw}_info.xlsx', xlsx_io, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))]
            data_payload = {'kw': kw, 'codigo_projeto': kw}
            r = requests.post(Config.PROCER_API_DOO, headers=headers, files=files_payload, data=data_payload, timeout=120)
        os.remove(temp_path); return jsonify({'success': True, 'message': 'Backup enviado!'})
    except Exception as e:
        if os.path.exists(temp_path): os.remove(temp_path)
        return jsonify({'error': str(e)}), 500

@procer_bp.route('/api/procer/buscar_item_erp')
def api_procer_buscar_erp():
    try: return jsonify(requests.get(Config.PROCER_API_BUSCA, headers={"authorization": Config.PROCER_TOKEN}, params={"filter": request.args.get('q','')}, timeout=10).json())
    except: return jsonify([])

@procer_bp.route('/api/procer/gerar_excel', methods=['POST'])
def api_procer_gerar_excel():
    try:
        dados = request.json.get('data', []); mode = request.json.get('mode', 'pcp'); wb = openpyxl.Workbook(); ws = wb.active; ws.append(["Código", "Desc", "Fab", "Qtd", "Status"])
        for d in dados:
            row = [d['codigo_useall'], d['descricao'], d['codigo_fab'], d['quantidade'], "Validado"]
            if mode == 'orcamento': row += [d.get('custo'), d.get('ipi'), d.get('total')]
            ws.append(row)
        out = BytesIO(); wb.save(out); out.seek(0)
        return send_file(out, as_attachment=True, download_name="Lista.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    except Exception as e: return jsonify({'error': str(e)}), 500