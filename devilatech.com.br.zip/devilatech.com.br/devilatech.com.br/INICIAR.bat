@echo off
title devilatech.com.br
color 0A

:: 1. Garante que o comando rode DENTRO da pasta do projeto
cd /d "%~dp0"

echo ==========================================
echo      INICIANDO SISTEMA DEVILA TECH
echo ==========================================
echo.

:: --- PARTE 1: DOCKER (O Motor do WhatsApp) ---
echo [1/4] Verificando Docker...
docker info >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    color 0C
    echo [ERRO] O Docker Desktop nao esta rodando!
    echo Por favor, abra o Docker Desktop e tente novamente.
    pause
    exit
)

echo [2/4] Subindo API do WhatsApp (Docker)...
:: O comando abaixo le o arquivo docker-compose.yml que criamos antes
docker-compose up -d

:: Roda o aplicativo
python run.py

:: Se der erro, nao fecha a janela na hora
echo.
echo ==========================================
echo O SERVIDOR PAROU.
echo Verifique o erro acima.
echo ==========================================
pause