import threading
from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix
from datetime import timedelta

# Importações dos nossos módulos
from config import Config
from database import init_dbs
from services.whatsapp_bot import verificar_lembretes_automaticos
from routes.auth import auth_bp
from routes.procer import procer_bp
from routes.carabeli import carabeli_bp

def create_app():
    app = Flask(__name__, template_folder='templates', static_folder='static')
    app.config.from_object(Config)
    app.permanent_session_lifetime = timedelta(days=30)
    
    # Registra as Rotas (Blueprints)
    app.register_blueprint(auth_bp)
    app.register_blueprint(procer_bp)
    app.register_blueprint(carabeli_bp)
    
    # Configuração de Proxy (Para rodar na web depois)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)
    
    return app

if __name__ == '__main__':
    # 1. Cria tabelas no banco se não existirem
    init_dbs()
    
    # 2. Inicia o Robô de WhatsApp em segundo plano
    threading.Thread(target=verificar_lembretes_automaticos, daemon=True).start()
    
    # 3. Inicia o Servidor Web
    app = create_app()
    from waitress import serve
    print("🚀 Servidor Devilatech MODULAR Rodando (Porta 8000)...", flush=True)
    # Aumentei threads para garantir que o webhook não trave se houver muitas requisições
    serve(app, host='0.0.0.0', port=8000, threads=16)