import os
import re
from config import Config

def padronizar_telefone(tel):
    if not tel: return ""
    nums = re.sub(r'\D', '', str(tel))
    if nums.startswith('55') and len(nums) in [12, 13]: return nums
    if len(nums) == 11: return '55' + nums 
    if len(nums) == 10: return '55' + nums 
    return nums

def get_target_folder(company, folder_id):
    company_path = os.path.join(Config.SAFE_UPLOADS_FOLDER, company)
    if not os.path.exists(company_path): os.makedirs(company_path)
    prefix = f"projeto_{folder_id}" if company == 'procer' else f"paciente_{folder_id}"
    
    for f in os.listdir(company_path):
        if f.startswith(prefix): return os.path.join(company_path, f), f
        
    new_name = f"{prefix}_Item"
    os.makedirs(os.path.join(company_path, new_name), exist_ok=True)
    return os.path.join(company_path, new_name), new_name