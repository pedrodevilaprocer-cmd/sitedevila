import time
import requests
from datetime import datetime, timedelta
from database import get_db_connection
from utils import padronizar_telefone

def enviar_whatsapp_api(telefone, mensagem):
    # API Local
    url = "http://127.0.0.1:8081/message/sendText/clinica_carabelli"
    payload = {
        "number": telefone,
        "options": {"delay": 2000, "presence": "composing"},
        "textMessage": {"text": mensagem}
    }
    headers = {"apikey": "123456", "Content-Type": "application/json"}
    
    try:
        print(f"   --> Enviando para {telefone}...", flush=True)
        r = requests.post(url, json=payload, headers=headers, timeout=10)
        return r.status_code == 201
    except Exception as e:
        print(f"   --> Erro no envio: {e}", flush=True)
        return False

def verificar_lembretes_automaticos():
    print("🤖 Robô de Lembretes INICIADO.", flush=True)
    while True:
        try:
            time.sleep(30)
            conn = get_db_connection('carabeli')
            cfg = conn.execute("SELECT * FROM whatsapp_config WHERE id=1").fetchone()
            conn.close()
            
            if not cfg or cfg['status'] != 'ativo': continue
            
            hora_alvo = cfg['hora_envio']
            agora = datetime.now()
            hora_atual = agora.strftime("%H:%M")
            
            if hora_atual == hora_alvo:
                print(f"⏰ Hora do Robô ({hora_alvo})! Iniciando disparos...", flush=True)
                
                # Datas
                amanha = agora + timedelta(days=1)
                data_banco = amanha.strftime('%Y-%m-%d')
                data_msg = amanha.strftime('%d/%m')      
                
                conn = get_db_connection('carabeli')
                agendas = conn.execute("""
                    SELECT a.paciente_nome, a.start_time, p.telefone 
                    FROM agenda a 
                    JOIN pacientes p ON a.paciente_id = p.id 
                    WHERE a.start_time LIKE ? 
                    AND a.status NOT IN ('Cancelado', 'Concluído', 'Confirmado')
                """, (f'{data_banco}%',)).fetchall()
                conn.close()
                
                print(f"📋 Encontrados {len(agendas)} pacientes para amanhã.", flush=True)
                
                for ag in agendas:
                    tel = padronizar_telefone(ag['telefone'])
                    nome = ag['paciente_nome'].split()[0].title()
                    hora = ag['start_time'].split('T')[1][:5]
                    
                    if tel:
                        # --- MENSAGEM FINAL AJUSTADA ---
                        msg = (
                            f"Olá, {nome}! 🦷\n\n"
                            f"Sua consulta é amanhã, {data_msg} às {hora}hs.\n\n"
                            f"Podemos confirmar?\n"
                            f"Responda somente SIM ou NÃO.\n\n"
                            f"(Caso não seja confirmado, o horário será cancelado automaticamente)\n\n"
                            f"Consultório Odontológico Carabelli"
                        )
                        
                        enviar_whatsapp_api(tel, msg)
                        time.sleep(10)
                
                time.sleep(65)
        except Exception as e:
            print(f"❌ Erro no Robô: {e}", flush=True)
            time.sleep(30)