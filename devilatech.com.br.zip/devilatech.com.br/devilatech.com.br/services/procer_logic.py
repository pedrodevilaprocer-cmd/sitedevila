import pdfplumber
import openpyxl
import re

def processar_logica_engenharia(file_path, quadro_name, mode='pcp'):
    extracted_data = []
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                tables = page.extract_tables()
                for table in tables:
                    if not table: continue
                    raw_headers = [h.replace('\n', '') if h else '' for h in table[0]]
                    if "Código do Fabricante" in raw_headers and "Código USEALL" in raw_headers:
                        col_indices = {header: idx for idx, header in enumerate(raw_headers)}
                        targets = ["Código do Fabricante", "Código USEALL", "Quantidade", "Kanban", "Designação", "Fornecedor"]
                        indices = [col_indices.get(t) for t in targets]
                        for raw_row in table[1:]:
                            vals = []
                            for idx in indices:
                                if idx is not None and idx < len(raw_row) and raw_row[idx]:
                                    vals.append(raw_row[idx].replace('\n', ' '))
                                else: vals.append("")
                            item = {'codigo_fab': vals[0], 'codigo_useall': vals[1], 'quantidade': vals[2].replace(',', '.'), 'kanban': vals[3], 'descricao': vals[4], 'fornecedor': vals[5], 'css_class': '', 'status_erp': 'Pendente'}
                            if item['codigo_useall']: extracted_data.append(item)
    except Exception as e: return [], [f"Erro PDF: {str(e)}"]
    
    priority_items = []; special_sort_items = []; normal_items = []
    kit1_triggers = {"1020000370", "1020000728", "1020000499", "1020000727", "1020000729"}
    kit2_triggers = {"102000136", "102000135", "1020000700", "1020000702", "1020000461", "1020000698", "1020000501", "102000139", "102000140", "1020000697", "102000138"}
    specific_priority = {"102000152", "102000158", "1020000999", "102000079"}
    kit1_active = False; kit2_active = False

    for item in extracted_data:
        code = item['codigo_useall']; desc_lower = item['descricao'].lower()
        if code in kit1_triggers: kit1_active = True
        if code == "102000136": kit2_active = True
        is_priority = code.startswith("101") or code.startswith("9595") or code in specific_priority
        is_special = desc_lower.startswith("canaleta") or desc_lower.startswith("trilho")
        if is_priority: priority_items.append(item)
        elif is_special: special_sort_items.append(item)
        else: normal_items.append(item)

    final_list = priority_items + special_sort_items + normal_items
    for it in final_list:
        code = it['codigo_useall']
        if it in priority_items: it['css_class'] = 'row-priority'
        elif it in special_sort_items: it['css_class'] = 'row-special'
        elif kit1_active and code in kit1_triggers: it['css_class'] = 'row-kit1'
        elif kit2_active and code in kit2_triggers: it['css_class'] = 'row-kit2'
        if mode == 'orcamento': it['custo'] = 0.0; it['ipi'] = 0.0; it['total'] = 0.0

    alerts = []
    checklist = {"1020000518": 4.0, "1020000644": 1.0, "1020000660": 2.0, "1020000710": 0.5}
    if "ROSCA" in quadro_name.upper() or "RV" in quadro_name.upper(): checklist["1020000641"] = 2.0
    counts = {}
    for it in final_list:
        try: counts[it['codigo_useall']] = counts.get(it['codigo_useall'], 0) + float(it['quantidade'])
        except: pass
    for code, req in checklist.items():
        if counts.get(code, 0) < req: alerts.append(f"Item {code} insuficiente ({counts.get(code,0)}/{req})")
    return final_list, alerts

def processar_chicote_excel(file_path, quadro_name):
    final_data = []
    try:
        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active
        col_secao = -1; col_cor = -1
        for row in ws.iter_rows(values_only=True):
            r = list(row); r_str = [str(x) if x else '' for x in r]
            if "Seção transversal / diâmetro da conexão com unidade" in r_str:
                col_secao = r_str.index("Seção transversal / diâmetro da conexão com unidade")
                col_cor = r_str.index("Cor / número da conexão"); break
        if col_secao == -1: return [], ["Cabeçalho não encontrado no Excel."]
        is_forca = "FORÇA" in quadro_name.upper(); is_comando = "COMANDO" in quadro_name.upper()
        unique_wires = set()
        for row in ws.iter_rows(min_row=2, values_only=True):
            try:
                secao_raw = str(row[col_secao]).strip().replace(',', '.'); cor_raw = str(row[col_cor]).strip().upper()
                if not secao_raw or not cor_raw: continue
                if 'X' in secao_raw.upper(): continue
                val = float(re.findall(r"[\d\.]+", secao_raw)[0])
                keep = False
                if is_forca and val > 0.5: keep = True
                elif is_comando and val == 0.5: keep = True
                elif not is_forca and not is_comando: keep = True
                if keep: unique_wires.add((f"{val}mm²", cor_raw))
            except: continue
        for s, c in unique_wires: final_data.append({'codigo_useall': '', 'descricao': f"Fio {s} - {c}", 'codigo_fab': c, 'quantidade': '1', 'status_erp': 'Buscar ERP', 'css_class': 'row-kit1'})
        return final_data, []
    except Exception as e: return [], [f"Erro Excel: {str(e)}"]