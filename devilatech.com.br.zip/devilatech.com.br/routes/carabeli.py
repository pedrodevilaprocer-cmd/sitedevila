import os
import time
import requests
import re
import json
import sys
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, render_template, session, redirect, send_from_directory
from config import Config
from database import get_db_connection
from utils import padronizar_telefone, get_target_folder
from services.whatsapp_bot import iniciar_sessao, enviar_whatsapp_api, obter_status, INSTANCE_NAME, API_URL, API_KEY

carabeli_bp = Blueprint('carabeli', __name__)

# ==============================================================================
# 🌐 ROTA DO DASHBOARD
# ==============================================================================
@carabeli_bp.route('/cliente/carabeli')
def rota_carabeli(): 
    if session.get('empresa') == 'carabeli':
        # Detecção de Dispositivo
        ua = request.headers.get('User-Agent', '').lower()
        is_mobile = 'mobile' in ua or 'android' in ua or 'iphone' in ua
        
        nome = session.get('nome', 'Doutora')
        
        if is_mobile:
            return render_template('clientes/carabeli_dashboard_mobile.html', user_name=nome)
        else:
            return render_template('clientes/carabeli_dashboard_pc.html', user_name=nome)
    else:
        return redirect('/login')

# ==============================================================================
# 🧠 CÉREBRO DO ROBÔ
# ==============================================================================
def processar_robo_inteligente(remote_jid, texto_msg, nome_push):
    try:
        conn = get_db_connection('carabeli')
        texto = texto_msg.lower().strip()
        
        # Busca flexível (últimos 8 dígitos)
        numeros = re.sub(r'\D', '', remote_jid)
        busca_flexivel = numeros[-8:] if len(numeros) > 8 else numeros

        ctx = conn.execute("SELECT * FROM chat_contexts WHERE remote_jid = ?", (remote_jid,)).fetchone()
        estagio = ctx['stage'] if ctx else None
        temp_data = ctx['temp_data'] if ctx else None

        # 1. CANCELAMENTO (NÃO)
        negativas = ['não', 'nao', 'cancelar', 'não vou', 'nao vou']
        if any(p in texto for p in negativas) and estagio is None:
            
            # Busca Paciente
            pacientes = conn.execute("SELECT id, nome, telefone FROM pacientes").fetchall()
            paciente = None
            for p in pacientes:
                if not p['telefone']: continue
                tel_db = re.sub(r'\D', '', str(p['telefone']))
                if busca_flexivel in tel_db:
                    paciente = p
                    break
            
            if paciente:
                hoje = datetime.now().strftime('%Y-%m-%d')
                # Busca agendamento futuro para cancelar
                ag = conn.execute("""
                    SELECT id FROM agenda 
                    WHERE paciente_id = ? AND start_time >= ? 
                    AND (status = 'Agendado' OR status = 'Confirmado') 
                    ORDER BY start_time ASC LIMIT 1
                """, (paciente['id'], hoje)).fetchone()
                
                if ag:
                    conn.execute("UPDATE agenda SET status = 'Cancelado' WHERE id = ?", (ag['id'],))
                    conn.execute("INSERT OR REPLACE INTO chat_contexts (remote_jid, stage, temp_data) VALUES (?, 'esperando_data', ?)", (remote_jid, str(paciente['id'])))
                    conn.commit()
                    enviar_whatsapp_api(remote_jid, "Poxa, que pena! 😕 Já cancelei aqui.\n\nQual dia ficaria bom para remarcarmos? (Ex: 10/01)")
                else:
                    enviar_whatsapp_api(remote_jid, "Não encontrei agendamentos futuros para cancelar.")
            else:
                print("   ❌ Paciente não encontrado no banco.")

        # 2. DATA (CORRIGIDO: Agora usa a função inteligente)
        elif estagio == 'esperando_data':
            # Chama a função que corrige o ano automaticamente
            data_iso = interpretar_data(texto)
            
            if not data_iso:
                enviar_whatsapp_api(remote_jid, "Não entendi a data. 📅 Digite dia/mês (Ex: 10/01).")
                return

            # Verifica agenda desse dia
            ocupados = conn.execute("SELECT start_time FROM agenda WHERE start_time LIKE ?", (f"{data_iso}%",)).fetchall()
            horas_ocup = [o['start_time'].split('T')[1][:5] for o in ocupados]
            
            # Lista de horários disponíveis
            livres = [h for h in ["08:00","09:00","10:00","11:00","13:00","14:00","15:00","16:00","17:00"] if h not in horas_ocup]
            
            # Atualiza contexto
            conn.execute("UPDATE chat_contexts SET stage = 'esperando_hora', temp_data = ? WHERE remote_jid = ?", 
                         (json.dumps({'pid': temp_data, 'data': data_iso}), remote_jid))
            conn.commit()
            
            if not livres:
                enviar_whatsapp_api(remote_jid, f"O dia {formatar_data_br(data_iso)} está lotado! 😕 Tente outra data.")
            else:
                lista = "\n".join([f"👉 {h}" for h in livres])
                enviar_whatsapp_api(remote_jid, f"Certo! Para {formatar_data_br(data_iso)}, tenho estes:\n\n{lista}\n\nQual prefere?")

        # 3. HORA
        elif estagio == 'esperando_hora':
            match = re.search(r'(\d{1,2})', texto)
            if match:
                h = match.group(1).zfill(2) + ":00"
                dado = json.loads(temp_data)
                
                # Busca nome para salvar na agenda
                p = conn.execute("SELECT nome FROM pacientes WHERE id=?", (dado['pid'],)).fetchone()
                nome_final = p['nome'] if p else nome_push

                start_time = f"{dado['data']}T{h}"
                conn.execute("INSERT INTO agenda (paciente_id, paciente_nome, start_time, status) VALUES (?, ?, ?, 'Confirmado')", 
                             (dado['pid'], nome_final, start_time))
                
                # Limpa contexto
                conn.execute("DELETE FROM chat_contexts WHERE remote_jid = ?", (remote_jid,))
                conn.commit()
                
                d_fmt = formatar_data_br(dado['data']) # Ex: 10/01
                enviar_whatsapp_api(remote_jid, f"Perfeito! 😍🦷\n\nAgendado para dia {d_fmt} às {h}.\n\nObrigada!")
            else:
                enviar_whatsapp_api(remote_jid, "Horário inválido. Escolha um da lista.")

        # 4. SIM / CONFIRMAR
        elif texto in ['sim', 's', 'confirmar', 'ok', 'pode ser']:
             pacientes = conn.execute("SELECT id, telefone FROM pacientes").fetchall()
             for p in pacientes:
                 if not p['telefone']: continue
                 tel_db = re.sub(r'\D', '', str(p['telefone']))
                 if busca_flexivel in tel_db:
                     hoje = datetime.now().strftime('%Y-%m-%d')
                     ag = conn.execute("SELECT id FROM agenda WHERE paciente_id = ? AND start_time >= ? AND status = 'Agendado'", (p['id'], hoje)).fetchone()
                     if ag:
                         conn.execute("UPDATE agenda SET status = 'Confirmado' WHERE id = ?", (ag['id'],))
                         conn.commit()
                         enviar_whatsapp_api(remote_jid, "Show! Seu horário está confirmado. Até lá! 👋")
                     break

    except Exception as e:
        print(f"❌ Erro Lógica: {e}")
    finally:
        conn.close()

# --- FUNÇÕES INTELIGENTES ---
def interpretar_data(texto):
    """
    Lê a data e se for menor que hoje, joga para o ano que vem.
    Ex: Hoje é 21/12/2025. Usuário pede 10/01. Retorna 2026-01-10.
    """
    hoje = datetime.now()
    
    if 'amanha' in texto or 'amanhã' in texto: 
        return (hoje + timedelta(days=1)).strftime('%Y-%m-%d')
    
    match = re.search(r'(\d{1,2})/(\d{1,2})', texto)
    if match:
        dia, mes = map(int, match.groups())
        ano = hoje.year
        
        try:
            # Cria a data com o ano atual
            data_tentativa = datetime(ano, mes, dia)
            
            # Se a data formada for anterior a hoje (ignorando horas), significa que é ano que vem
            if data_tentativa.date() < hoje.date():
                ano += 1
            
            return f"{ano}-{str(mes).zfill(2)}-{str(dia).zfill(2)}"
        except ValueError:
            return None # Data invalida (ex: 30/02)
            
    return None

def formatar_data_br(iso): 
    # 2026-01-10 -> 10/01
    p = iso.split('-')
    return f"{p[2]}/{p[1]}"

# ==============================================================================
# 🤖 WEBHOOK
# ==============================================================================
@carabeli_bp.route('/api/webhook/whatsapp', methods=['POST'])
def whatsapp_webhook():
    try:
        raw = request.json
        evento = raw.get('event') or raw.get('type')
        
        if evento not in ['messages.upsert', 'MESSAGES_UPSERT']: return 'OK', 200
        
        data = raw.get('data', {})
        key = data.get('key', {})
        if key.get('fromMe'): return 'OK', 200
        
        remote_jid = key.get('remoteJid')
        msg_content = data.get('message', {})
        
        texto = ""
        if 'conversation' in msg_content: texto = msg_content['conversation']
        elif 'extendedTextMessage' in msg_content: texto = msg_content['extendedTextMessage'].get('text', '')
            
        if not texto: return 'OK', 200
        
        push_name = data.get('pushName', 'Paciente')
        
        print(f"📩 WEBHOOK: {push_name} -> {texto}", flush=True)
        
        # Salva
        conn = get_db_connection('carabeli')
        jid_clean = remote_jid.replace('@s.whatsapp.net', '')
        check = conn.execute("SELECT real_id FROM id_corrections WHERE wrong_id = ?", (re.sub(r'\D','',jid_clean),)).fetchone()
        final_jid = check['real_id'] if check else jid_clean

        conn.execute("INSERT INTO messages (remote_jid, paciente_nome, direction, message, read) VALUES (?, ?, 'in', ?, 0)", (final_jid, push_name, texto))
        conn.commit()
        conn.close()
        
        processar_robo_inteligente(remote_jid, texto, push_name)
        
        return 'OK', 200
    except:
        return 'Error', 500

# -- MANTENHA AS DEMAIS ROTAS IGUAIS (AGENDA, FINANCEIRO, ETC) --
# Para economizar espaço aqui, estou assumindo que você manterá as rotas
# /api/clinica/agenda, /api/clinica/whatsapp/*, etc. do arquivo anterior.
# Elas são essenciais para o painel funcionar.
# ... (Cole aqui o restante das rotas api_* do passo anterior) ...
@carabeli_bp.route('/api/clinica/agenda', methods=['GET','POST','DELETE','PUT'])
def api_agenda_clinica():
    conn = get_db_connection('carabeli')
    if request.method=='GET': r=conn.execute("SELECT * FROM agenda WHERE status != 'Cancelado'").fetchall(); conn.close(); return jsonify([{'id':x['id'],'title':x['paciente_nome'],'start':x['start_time'],'status':x['status'],'paciente_id':x['paciente_id']} for x in r])
    if request.method=='POST': conn.execute("INSERT INTO agenda (paciente_id, paciente_nome, start_time, status) VALUES (?,?,?,?)",(request.json['paciente_id'],request.json['paciente_nome'],request.json['start'], 'Agendado')); conn.commit()
    if request.method=='DELETE': conn.execute("DELETE FROM agenda WHERE id=?",(request.args.get('id'),)); conn.commit()
    if request.method=='PUT': conn.execute("UPDATE agenda SET status=? WHERE id=?", (request.json['status'], request.json['id'])); conn.commit()
    conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/clinica/whatsapp/connect')
def api_wa_conn(): return jsonify(iniciar_sessao())

@carabeli_bp.route('/api/clinica/whatsapp/logout', methods=['DELETE'])
def api_wa_logout():
    try: requests.delete(f"{API_URL}/instance/logout/{INSTANCE_NAME}", headers={"apikey": API_KEY}, timeout=5); return jsonify({'success':True})
    except: return jsonify({'success':False})

@carabeli_bp.route('/api/clinica/whatsapp/config', methods=['GET','POST'])
def api_wa_cfg(): 
    conn=get_db_connection('carabeli')
    if request.method=='GET': r=conn.execute("SELECT * FROM whatsapp_config").fetchone(); conn.close(); return jsonify(dict(r))
    conn.execute("UPDATE whatsapp_config SET hora_envio=?, status=?",(request.json['hora_envio'],request.json['status'])); conn.commit(); conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/preencher_ficha/<int:id>', methods=['GET', 'POST'])
def preencher_ficha(id):
    conn = get_db_connection('carabeli')
    if request.method == 'POST': conn.execute('UPDATE pacientes SET anamnese = ? WHERE id = ?', (request.form.get('anamnese_completa'), id)); conn.commit(); conn.close(); return render_template('anamnese_paciente.html', sucesso=True)
    p = conn.execute("SELECT * FROM pacientes WHERE id=?", (id,)).fetchone(); conn.close()
    return render_template('anamnese_paciente.html', nome_paciente=p['nome'], sucesso=False) if p else "Paciente não encontrado."

@carabeli_bp.route('/api/clinica/pacientes')
def api_pacientes():
    q = request.args.get('q', '').strip()
    conn = get_db_connection('carabeli')
    
    if q:
        # Busca por Nome OU CPF OU Telefone
        wildcard = f"%{q}%"
        query = """
            SELECT * FROM pacientes 
            WHERE nome LIKE ? 
            OR cpf LIKE ? 
            OR telefone LIKE ? 
            LIMIT 50
        """
        p = conn.execute(query, (wildcard, wildcard, wildcard)).fetchall()
    else:
        p = conn.execute("SELECT * FROM pacientes LIMIT 50").fetchall()
        
    conn.close()
    return jsonify([dict(x) for x in p])

@carabeli_bp.route('/api/clinica/paciente/novo', methods=['POST'])
def api_pac_novo():
    d=request.json; conn=get_db_connection('carabeli')
    conn.execute("INSERT INTO pacientes (nome, cpf, telefone) VALUES (?,?,?)", (d['nome'],d.get('cpf'),d.get('telefone'))); conn.commit(); conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/clinica/paciente/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def api_pac_single(id):
    conn = get_db_connection('carabeli')
    if request.method=='GET': p=conn.execute("SELECT * FROM pacientes WHERE id=?",(id,)).fetchone(); conn.close(); return jsonify(dict(p)) if p else jsonify({})
    if request.method=='DELETE': conn.execute("DELETE FROM pacientes WHERE id=?",(id,)); conn.commit(); conn.close(); return jsonify({'success':True})
    d=request.json; conn.execute("UPDATE pacientes SET nome=?, cpf=?, telefone=? WHERE id=?", (d['nome'],d.get('cpf'),d.get('telefone'), id)); conn.commit(); conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/clinica/financeiro/<pid>', methods=['GET','POST'])
def api_fin(pid):
    conn=get_db_connection('carabeli')
    if request.method=='POST': d=request.json; conn.execute("INSERT INTO financeiro (paciente_id, data, servico, valor) VALUES (?,?,?,?)",(pid,d['data'],d['servico'],d['valor'])); conn.commit()
    h=conn.execute("SELECT * FROM financeiro WHERE paciente_id=?",(pid,)).fetchall(); p=conn.execute("SELECT nome FROM pacientes WHERE id=?", (pid,)).fetchone(); conn.close(); return jsonify({'historico':[dict(x) for x in h], 'paciente': dict(p) if p else {'nome': 'Desconhecido'}})

@carabeli_bp.route('/api/clinica/estoque', methods=['GET','POST','DELETE'])
def api_est():
    conn=get_db_connection('carabeli')
    if request.method=='GET': r=conn.execute("SELECT * FROM estoque").fetchall(); conn.close(); return jsonify([dict(x) for x in r])
    if request.method=='POST': d=request.json; conn.execute("INSERT INTO estoque (item, qtd, unidade, validade) VALUES (?,?,?,?)",(d['item'],d['qtd'],d['unidade'],d['validade'])); conn.commit()
    if request.method=='DELETE': conn.execute("DELETE FROM estoque WHERE id=?",(request.args.get('id'),)); conn.commit()
    conn.close(); return jsonify({'success':True})

@carabeli_bp.route('/api/chat/contacts')
def api_chat_contacts(): 
    conn=get_db_connection('carabeli')
    c=conn.execute("SELECT remote_jid, paciente_nome, message, timestamp, (SELECT COUNT(*) FROM messages m2 WHERE m2.remote_jid = m1.remote_jid AND m2.read = 0) as unread FROM messages m1 GROUP BY remote_jid ORDER BY timestamp DESC").fetchall()
    conn.close()
    return jsonify([dict(x) for x in c])

@carabeli_bp.route('/api/chat/history/<jid>')
def api_chat_history(jid): 
    conn=get_db_connection('carabeli')
    clean_jid = re.sub(r'\D', '', jid)
    m=conn.execute("SELECT * FROM messages WHERE remote_jid LIKE ? ORDER BY timestamp ASC", (f'%{clean_jid}%',)).fetchall()
    conn.execute("UPDATE messages SET read=1 WHERE remote_jid LIKE ?", (f'%{clean_jid}%',))
    conn.commit()
    conn.close()
    return jsonify([dict(x) for x in m])

@carabeli_bp.route('/api/chat/profile_pic/<jid>')
def api_chat_pfp(jid):
    headers = {"apikey": API_KEY}
    try:
        num = re.sub(r'\D', '', jid)
        if len(num) <= 11: num = '55' + num
        r = requests.post(f"{API_URL}/chat/fetchProfilePictureUrl/{INSTANCE_NAME}", json={"number": num}, headers=headers, timeout=3)
        if r.status_code == 200:
            data = r.json()
            url = data.get('profilePictureUrl')
            if url: return jsonify({'url': url})
    except: pass
    return jsonify({'url': None})

@carabeli_bp.route('/api/chat/send', methods=['POST'])
def api_chat_send():
    d=request.json; jid=padronizar_telefone(d['jid'])
    if enviar_whatsapp_api(jid, d['message']):
        conn=get_db_connection('carabeli'); 
        conn.execute("INSERT INTO messages (remote_jid, paciente_nome, direction, message, read) VALUES (?, ?, 'out', ?, 1)", (jid, d.get('name', jid), d['message'])); 
        conn.commit(); conn.close(); 
        return jsonify({'success':True})
    return jsonify({'success':False}), 500

@carabeli_bp.route('/api/clinica/faturamento_hoje')
def api_fat_hoje(): conn = get_db_connection('carabeli'); hoje = datetime.now().strftime('%Y-%m-%d'); res = conn.execute("SELECT SUM(valor) as total FROM financeiro WHERE data = ?", (hoje,)).fetchone(); conn.close(); return jsonify({'total': res['total'] if res and res['total'] else 0.0})

@carabeli_bp.route('/api/clinica/relatorios')
def api_relatorios(): conn = get_db_connection('carabeli'); fin = conn.execute("SELECT f.*, p.nome as paciente_nome FROM financeiro f LEFT JOIN pacientes p ON f.paciente_id = p.id ORDER BY f.data DESC").fetchall(); conn.close(); return jsonify({'financeiro': [dict(x) for x in fin]})

@carabeli_bp.route('/api/anexos/<target_id>', methods=['GET','POST','DELETE'])
def api_anexos(target_id):
    emp=session.get('empresa','carabeli'); full_path,_=get_target_folder(emp, target_id)
    if request.method=='POST': f=request.files['file']; f.save(os.path.join(full_path, secure_filename(f.filename))); return jsonify({'success':True})
    if request.method=='DELETE': 
        try: os.remove(os.path.join(full_path, request.json['filename']))
        except: pass
        return jsonify({'success':True})
    try: files = [{'name':f,'url':f"/arquivo_seguro/{emp}/{os.path.basename(full_path)}/{f}", 'is_dir':False, 'can_delete':True} for f in os.listdir(full_path)]
    except: files = []
    return jsonify({'items': files})

@carabeli_bp.route('/arquivo_seguro/<company>/<folder>/<filename>')
def serve_file(company, folder, filename): return send_from_directory(os.path.join(Config.SAFE_UPLOADS_FOLDER, company, folder), filename)

@carabeli_bp.route('/api/clinica/fix_id', methods=['GET', 'POST', 'DELETE'])
def api_fix_id():
    conn = get_db_connection('carabeli')
    if request.method == 'POST':
        wrong = re.sub(r'\D', '', request.json['wrong_id'])
        real = re.sub(r'\D', '', request.json['real_id'])
        conn.execute("INSERT OR REPLACE INTO id_corrections (wrong_id, real_id) VALUES (?, ?)", (wrong, real))
        conn.execute("UPDATE messages SET remote_jid = ? WHERE remote_jid LIKE ?", (real, f'%{wrong}%'))
        conn.execute("UPDATE chat_contexts SET remote_jid = ? WHERE remote_jid LIKE ?", (real, f'%{wrong}%'))
        conn.commit(); conn.close()
        return jsonify({'success': True})
    if request.method == 'GET':
        rows = conn.execute("SELECT * FROM id_corrections").fetchall(); conn.close()
        return jsonify([dict(x) for x in rows])
    if request.method == 'DELETE':
        conn.execute("DELETE FROM id_corrections WHERE wrong_id = ?", (request.args.get('wrong_id'),)); conn.commit(); conn.close()
        return jsonify({'success': True})