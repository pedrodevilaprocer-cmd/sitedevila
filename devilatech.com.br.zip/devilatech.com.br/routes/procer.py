from flask import Blueprint, render_template, jsonify
from database import get_db_connection

procer_bp = Blueprint('procer', __name__)

# --- 1. ROTA DO DASHBOARD (A Principal) ---
@procer_bp.route('/cliente/procer')
def procer_dashboard():
    # Renderiza o painel principal (que já funcionou na sua imagem)
    return render_template('clientes/procer_dashboard.html')

# --- 2. ROTA DE TESTES DE QUADROS ---
# URL solicitada: https://devilatech.com.br/cliente/procer/testes/lista
@procer_bp.route('/cliente/procer/testes/lista')
def page_testes():
    # Aponta para o arquivo: templates/clientes/procer_testes.html
    return render_template('clientes/procer_testes.html')

# --- 3. ROTA DE PROJETOS ELÉTRICOS ---
# URL solicitada: https://devilatech.com.br/cliente/procer/projetos
@procer_bp.route('/cliente/procer/projetos')
def page_projetos():
    # Aponta para o arquivo: templates/clientes/procer_projetos.html
    return render_template('clientes/procer_projetos.html')

# --- 4. API DE DADOS (Para preencher as tabelas) ---
@procer_bp.route('/api/procer/dados')
def api_dados():
    try:
        conn = get_db_connection('carabeli')
        # Pega os dados da tabela procer_projetos
        rows = conn.execute("SELECT * FROM procer_projetos").fetchall()
        conn.close()
        
        lista_final = []
        for row in rows:
            item = dict(row)
            status = str(item['status'] or '').upper()
            
            # Lógica de Status
            if 'DESENVOLVIDO' in status:
                item['tipo'] = 'concluido'
            else:
                item['tipo'] = 'pendente'
                
            lista_final.append(item)
            
        return jsonify(lista_final)
    except Exception as e:
        print(f"Erro na API Procer: {e}")
        return jsonify({'error': str(e)}), 500