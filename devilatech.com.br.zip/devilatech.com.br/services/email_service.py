import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr  # <--- IMPORTANTE: Função para formatar nomes
from dotenv import load_dotenv

load_dotenv()

def enviar_email_verificacao(destinatario, nome, codigo):
    # Configurações do .env
    smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
    smtp_port = int(os.getenv('SMTP_PORT', 587))
    
    # Credenciais de Login (Seu Gmail Pessoal)
    smtp_user = os.getenv('EMAIL_USER')
    smtp_pass = os.getenv('EMAIL_PASS')

    # O E-mail que deve aparecer (Alias)
    smtp_sender_email = os.getenv('EMAIL_SENDER', 'contato@devilatech.com.br')
    
    # NOME QUE VAI APARECER (Isso sobrescreve o "Pedro")
    nome_remetente = "DevilaTech Security"

    if not smtp_user or not smtp_pass:
        print("❌ ERRO: Credenciais ausentes.")
        return False

    # Limpeza da senha
    smtp_pass = smtp_pass.replace(" ", "")

    msg = MIMEMultipart()
    
    # --- A MÁGICA ACONTECE AQUI ---
    # formataddr cria o cabeçalho perfeito: "DevilaTech Security <contato@devilatech...>"
    msg['From'] = formataddr((nome_remetente, smtp_sender_email))
    # ------------------------------
    
    msg['To'] = destinatario
    msg['Subject'] = "🔐 Código de Verificação - DevilaTech"
    
    html_content = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #0f172a; color: #ffffff; padding: 40px;">
        <div style="max-width: 500px; margin: 0 auto; background-color: #1e293b; padding: 30px; border-radius: 10px; border: 1px solid #334155;">
            <div style="text-align: center; margin-bottom: 20px;">
                <h2 style="color: #38bdf8; margin: 0;">DEVILA TECH</h2>
            </div>
            <p>Olá, <strong>{nome}</strong>.</p>
            <p>Seu código de acesso é:</p>
            <div style="background-color: #0f172a; padding: 15px; text-align: center; font-size: 32px; font-weight: bold; color: #22c55e; letter-spacing: 5px; border-radius: 8px; margin: 20px 0;">
                {codigo}
            </div>
            <p style="font-size: 12px; color: #94a3b8; text-align: center;">Segurança DevilaTech.</p>
        </div>
    </body>
    </html>
    """
    msg.attach(MIMEText(html_content, 'html'))

    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.ehlo()
        server.starttls()
        server.ehlo()
        
        # Loga com o Pessoal
        server.login(smtp_user, smtp_pass)
        
        # Envia usando o Alias
        server.sendmail(smtp_sender_email, destinatario, msg.as_string())
        
        server.quit()
        print(f"✅ E-mail enviado como: {nome_remetente} <{smtp_sender_email}>")
        return True
    except Exception as e:
        print(f"❌ Erro ao enviar: {e}")
        return False