import requests
import json
import re
import time
import os
import socket
from datetime import datetime, timedelta
from database import get_db_connection

# ==============================================================================
# CONFIGURAÇÕES
# ==============================================================================
API_URL = os.getenv("EVOLUTION_URL", "http://localhost:8081").rstrip('/')
API_KEY = os.getenv("EVOLUTION_API_KEY", "devilatech_evolution_key_2025")
INSTANCE_NAME = os.getenv("EVOLUTION_INSTANCE", "clinica_carabelli")

# --- DESCOBRIR IP REAL DA MÁQUINA ---
def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Conecta num DNS público para saber qual a placa de rede usada
        s.connect(('8.8.8.8', 80))
        IP = s.getsockname()[0]
    except Exception:
        IP = 'host.docker.internal'
    finally:
        s.close()
    return IP

MEU_IP = get_local_ip()
# URL ONDE O PYTHON ESTÁ RODANDO
WEBHOOK_URL = f"http://{MEU_IP}:8000/api/webhook/whatsapp"

print(f"\n=======================================================")
print(f"📡 IP DETECTADO: {MEU_IP}")
print(f"🔗 WEBHOOK ALVO: {WEBHOOK_URL}")
print(f"=======================================================\n")

def get_headers():
    return { "Content-Type": "application/json", "apikey": API_KEY }

def criar_instancia_se_nao_existir():
    try:
        r = requests.get(f"{API_URL}/instance/fetchInstances", headers=get_headers(), timeout=5)
        if r.status_code != 200: return
        
        # Lógica para verificar se existe (Evolution v2 retorna array)
        instances = r.json()
        exists = False
        if isinstance(instances, list):
            exists = any(i.get('name') == INSTANCE_NAME for i in instances)
        
        if not exists:
            print(f"⚙️ [EVOLUTION] Criando instância...")
            payload = { "instanceName": INSTANCE_NAME, "qrcode": True, "integration": "WHATSAPP-BAILEYS" }
            requests.post(f"{API_URL}/instance/create", json=payload, headers=get_headers())
            time.sleep(5)
        
        # SEMPRE RECONFIGURA O WEBHOOK AO INICIAR
        configurar_webhook()
    except Exception as e:
        print(f"❌ Erro ao conectar na API: {e}")

def configurar_webhook():
    print(f"🔄 [WEBHOOK] Enviando configuração para a Evolution...")
    payload = { 
        "webhook": { 
            "enabled": True, 
            "url": WEBHOOK_URL, 
            "byEvents": False, # False = Envia tudo (Garante recebimento)
            "events": ["MESSAGES_UPSERT", "CONNECTION_UPDATE"] 
        } 
    }
    try: 
        r = requests.post(f"{API_URL}/webhook/set/{INSTANCE_NAME}", json=payload, headers=get_headers())
        if r.status_code in [200, 201]:
            print(f"✅ [WEBHOOK] Configurado com sucesso! O Docker vai enviar para {MEU_IP}.")
        else:
            print(f"⚠️ [WEBHOOK] API retornou erro: {r.text}")
    except Exception as e:
        print(f"❌ [WEBHOOK] Falha ao configurar: {e}")

def obter_status():
    try:
        r = requests.get(f"{API_URL}/instance/connectionState/{INSTANCE_NAME}", headers=get_headers(), timeout=3)
        if r.status_code in [200, 201]:
            return r.json().get('instance', {}).get('state') or 'close'
    except: pass
    return 'offline'

def iniciar_sessao():
    criar_instancia_se_nao_existir()
    if obter_status() == 'open': return {'status': 'connected'}
    try:
        r = requests.get(f"{API_URL}/instance/connect/{INSTANCE_NAME}", headers=get_headers(), timeout=10)
        data = r.json()
        if data.get('base64'): return {'status': 'qrcode', 'base64': data.get('base64')}
        if data.get('state') == 'open': return {'status': 'connected'}
    except: return {'status': 'loading'}
    return {'status': 'loading'}

def enviar_whatsapp_api(numero, mensagem):
    # Formatação robusta
    nums = re.sub(r'\D', '', str(numero))
    if len(nums) in [10, 11]: nums = '55' + nums
    jid = f"{nums}@s.whatsapp.net"
    
    print(f"📤 [ENVIO] Enviando para: {jid}")
    try:
        requests.post(f"{API_URL}/message/sendText/{INSTANCE_NAME}", 
                      json={"number": jid, "text": mensagem, "delay": 2000, "linkPreview": False}, 
                      headers=get_headers(), timeout=10)
        return True
    except: return False

def verificar_lembretes_automaticos():
    """
    LOOP DO ROBÔ
    """
    print("⏰ [SISTEMA] Robô iniciado.")
    time.sleep(5)
    
    # Garante configuração inicial
    criar_instancia_se_nao_existir()

    while True:
        try:
            # 1. Verifica hora (Formato HH:MM)
            agora = datetime.now().strftime('%H:%M')
            
            # 2. Verifica se está conectado
            if obter_status() != 'open':
                # Se cair a conexão, tenta reconectar webhook a cada minuto por segurança
                # print("💤 [ROBÔ] Aguardando conexão do WhatsApp...")
                pass
            else:
                conn = get_db_connection('carabeli')
                cfg = conn.execute("SELECT hora_envio, status FROM whatsapp_config").fetchone()
                
                # Se hora bater e estiver ativo
                if cfg and cfg['status'] == 'ativo' and cfg['hora_envio'] == agora:
                    print(f"\n🔔 [ROBÔ] Hora do disparo ({agora})! Iniciando...")
                    executar_envio_em_massa(conn)
                    print("⏳ [ROBÔ] Aguardando próximo ciclo (60s)...")
                    time.sleep(61)
                
                conn.close()
            
            time.sleep(30) # Verifica o relógio a cada 30s
            
        except Exception as e:
            print(f"❌ [ROBÔ] Erro no loop: {e}")
            time.sleep(30)

def executar_envio_em_massa(conn):
    hoje = datetime.now()
    amanha = (hoje + timedelta(days=1)).strftime('%Y-%m-%d')
    dia_mes = f"{amanha.split('-')[2]}/{amanha.split('-')[1]}"
    
    query = """
        SELECT a.id, a.start_time, a.paciente_nome, p.telefone 
        FROM agenda a JOIN pacientes p ON a.paciente_id = p.id
        WHERE a.start_time LIKE ? 
        AND (a.status = 'Agendado' OR a.status = 'Confirmado')
    """
    agendamentos = conn.execute(query, (f'{amanha}%',)).fetchall()
    
    if not agendamentos:
        print("ℹ️ [ROBÔ] Agenda vazia para amanhã.")
        return

    enviados = 0
    for ag in agendamentos:
        hora = ag['start_time'].split('T')[1][:5]
        nome = ag['paciente_nome'].split()[0]
        tel = ag['telefone']

        if not tel: continue

        msg = (
            f"Olá, {nome}! 🦷\n\n"
            f"Sua consulta é amanhã, {dia_mes} às {hora}hs.\n\n"
            f"Podemos confirmar?\n"
            f"Responda somente SIM ou NÃO.\n\n"
            f"(Caso não seja confirmado, o horário será cancelado automaticamente)\n\n"
            f"Consultório Odontológico Carabelli"
        )
        
        if enviar_whatsapp_api(tel, msg):
            enviados += 1
            time.sleep(5)
    
    print(f"✅ [ROBÔ] {enviados} mensagens enviadas.")