import os
from flask import Flask, redirect, session
from datetime import timedelta
from dotenv import load_dotenv

# Carrega variáveis de ambiente
load_dotenv()

# --- IMPORTAÇÃO DAS ROTAS ---
from routes.auth import auth_bp         # Sistema de Login
from routes.carabeli import carabeli_bp # Painel da Clínica Carabelli
from routes.procer import procer_bp     # Painel da Procer

app = Flask(__name__)

# --- CONFIGURAÇÕES DE SEGURANÇA ---
app.secret_key = os.getenv('SECRET_KEY', 'segredo_devila_tech_fixo')
app.permanent_session_lifetime = timedelta(days=7) # Login dura 7 dias

# --- REGISTRO DAS ROTAS ---
app.register_blueprint(auth_bp)
app.register_blueprint(carabeli_bp)
app.register_blueprint(procer_bp)

# --- ROTA INICIAL ---
@app.route('/')
def index():
    if 'user_id' in session:
        empresa = session.get('empresa')
        
        # Redireciona para o painel correto baseado na empresa
        if empresa == 'carabeli':
            return redirect('/cliente/carabeli')
        
        if empresa == 'procer':
            return redirect('/cliente/procer')
        
        # Fallback de segurança
        return redirect('/cliente/carabeli')

    # Se não estiver logado
    return redirect('/login')

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8000))
    app.run(host='0.0.0.0', port=port, debug=True)